/****************************************************************************
** Meta object code from reading C++ file 'ExitPage.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../ExitPage.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ExitPage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ExitPage_t {
    QByteArrayData data[1];
    char stringdata0[9];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ExitPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ExitPage_t qt_meta_stringdata_ExitPage = {
    {
QT_MOC_LITERAL(0, 0, 8) // "ExitPage"

    },
    "ExitPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ExitPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void ExitPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject ExitPage::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_ExitPage.data,
    qt_meta_data_ExitPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ExitPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ExitPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ExitPage.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int ExitPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_EarningsPage_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_EarningsPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_EarningsPage_t qt_meta_stringdata_EarningsPage = {
    {
QT_MOC_LITERAL(0, 0, 12) // "EarningsPage"

    },
    "EarningsPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_EarningsPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void EarningsPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject EarningsPage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_EarningsPage.data,
    qt_meta_data_EarningsPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *EarningsPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *EarningsPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_EarningsPage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int EarningsPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_OneMoreDayPage_t {
    QByteArrayData data[1];
    char stringdata0[15];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_OneMoreDayPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_OneMoreDayPage_t qt_meta_stringdata_OneMoreDayPage = {
    {
QT_MOC_LITERAL(0, 0, 14) // "OneMoreDayPage"

    },
    "OneMoreDayPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_OneMoreDayPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void OneMoreDayPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject OneMoreDayPage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_OneMoreDayPage.data,
    qt_meta_data_OneMoreDayPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *OneMoreDayPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *OneMoreDayPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_OneMoreDayPage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int OneMoreDayPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_NoMoreDaysPage_t {
    QByteArrayData data[1];
    char stringdata0[15];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NoMoreDaysPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NoMoreDaysPage_t qt_meta_stringdata_NoMoreDaysPage = {
    {
QT_MOC_LITERAL(0, 0, 14) // "NoMoreDaysPage"

    },
    "NoMoreDaysPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NoMoreDaysPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void NoMoreDaysPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject NoMoreDaysPage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_NoMoreDaysPage.data,
    qt_meta_data_NoMoreDaysPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *NoMoreDaysPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NoMoreDaysPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_NoMoreDaysPage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int NoMoreDaysPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_NoAdminPage_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NoAdminPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NoAdminPage_t qt_meta_stringdata_NoAdminPage = {
    {
QT_MOC_LITERAL(0, 0, 11) // "NoAdminPage"

    },
    "NoAdminPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NoAdminPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void NoAdminPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject NoAdminPage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_NoAdminPage.data,
    qt_meta_data_NoAdminPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *NoAdminPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NoAdminPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_NoAdminPage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int NoAdminPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_WrongInstallLocationPage_t {
    QByteArrayData data[1];
    char stringdata0[25];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_WrongInstallLocationPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_WrongInstallLocationPage_t qt_meta_stringdata_WrongInstallLocationPage = {
    {
QT_MOC_LITERAL(0, 0, 24) // "WrongInstallLocationPage"

    },
    "WrongInstallLocationPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_WrongInstallLocationPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void WrongInstallLocationPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject WrongInstallLocationPage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_WrongInstallLocationPage.data,
    qt_meta_data_WrongInstallLocationPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *WrongInstallLocationPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *WrongInstallLocationPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_WrongInstallLocationPage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int WrongInstallLocationPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_GoodbyePage_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GoodbyePage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GoodbyePage_t qt_meta_stringdata_GoodbyePage = {
    {
QT_MOC_LITERAL(0, 0, 11) // "GoodbyePage"

    },
    "GoodbyePage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GoodbyePage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void GoodbyePage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject GoodbyePage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_GoodbyePage.data,
    qt_meta_data_GoodbyePage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GoodbyePage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GoodbyePage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GoodbyePage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int GoodbyePage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_RestartPage_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RestartPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RestartPage_t qt_meta_stringdata_RestartPage = {
    {
QT_MOC_LITERAL(0, 0, 11) // "RestartPage"

    },
    "RestartPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RestartPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void RestartPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject RestartPage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_RestartPage.data,
    qt_meta_data_RestartPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *RestartPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RestartPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_RestartPage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int RestartPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_TimeoutSplashPage_t {
    QByteArrayData data[1];
    char stringdata0[18];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TimeoutSplashPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TimeoutSplashPage_t qt_meta_stringdata_TimeoutSplashPage = {
    {
QT_MOC_LITERAL(0, 0, 17) // "TimeoutSplashPage"

    },
    "TimeoutSplashPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TimeoutSplashPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void TimeoutSplashPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject TimeoutSplashPage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_TimeoutSplashPage.data,
    qt_meta_data_TimeoutSplashPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *TimeoutSplashPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TimeoutSplashPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TimeoutSplashPage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int TimeoutSplashPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_RetryPage_t {
    QByteArrayData data[1];
    char stringdata0[10];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RetryPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RetryPage_t qt_meta_stringdata_RetryPage = {
    {
QT_MOC_LITERAL(0, 0, 9) // "RetryPage"

    },
    "RetryPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RetryPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void RetryPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject RetryPage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_RetryPage.data,
    qt_meta_data_RetryPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *RetryPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RetryPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_RetryPage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int RetryPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_CompNotEligiblePage_t {
    QByteArrayData data[1];
    char stringdata0[20];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CompNotEligiblePage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CompNotEligiblePage_t qt_meta_stringdata_CompNotEligiblePage = {
    {
QT_MOC_LITERAL(0, 0, 19) // "CompNotEligiblePage"

    },
    "CompNotEligiblePage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CompNotEligiblePage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void CompNotEligiblePage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject CompNotEligiblePage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_CompNotEligiblePage.data,
    qt_meta_data_CompNotEligiblePage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CompNotEligiblePage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CompNotEligiblePage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CompNotEligiblePage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int CompNotEligiblePage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_WaitPage_t {
    QByteArrayData data[1];
    char stringdata0[9];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_WaitPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_WaitPage_t qt_meta_stringdata_WaitPage = {
    {
QT_MOC_LITERAL(0, 0, 8) // "WaitPage"

    },
    "WaitPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_WaitPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void WaitPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject WaitPage::staticMetaObject = { {
    QMetaObject::SuperData::link<ExitPage::staticMetaObject>(),
    qt_meta_stringdata_WaitPage.data,
    qt_meta_data_WaitPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *WaitPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *WaitPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_WaitPage.stringdata0))
        return static_cast<void*>(this);
    return ExitPage::qt_metacast(_clname);
}

int WaitPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ExitPage::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
