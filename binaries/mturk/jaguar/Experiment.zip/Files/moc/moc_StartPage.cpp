/****************************************************************************
** Meta object code from reading C++ file 'StartPage.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../StartPage.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'StartPage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_StartPage_t {
    QByteArrayData data[1];
    char stringdata0[10];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_StartPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_StartPage_t qt_meta_stringdata_StartPage = {
    {
QT_MOC_LITERAL(0, 0, 9) // "StartPage"

    },
    "StartPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_StartPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void StartPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject StartPage::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_StartPage.data,
    qt_meta_data_StartPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *StartPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *StartPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_StartPage.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int StartPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_ModPage_t {
    QByteArrayData data[1];
    char stringdata0[8];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ModPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ModPage_t qt_meta_stringdata_ModPage = {
    {
QT_MOC_LITERAL(0, 0, 7) // "ModPage"

    },
    "ModPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ModPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void ModPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject ModPage::staticMetaObject = { {
    QMetaObject::SuperData::link<StartPage::staticMetaObject>(),
    qt_meta_stringdata_ModPage.data,
    qt_meta_data_ModPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ModPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ModPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ModPage.stringdata0))
        return static_cast<void*>(this);
    return StartPage::qt_metacast(_clname);
}

int ModPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = StartPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_HoursMonitorPage_t {
    QByteArrayData data[1];
    char stringdata0[17];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_HoursMonitorPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_HoursMonitorPage_t qt_meta_stringdata_HoursMonitorPage = {
    {
QT_MOC_LITERAL(0, 0, 16) // "HoursMonitorPage"

    },
    "HoursMonitorPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_HoursMonitorPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void HoursMonitorPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject HoursMonitorPage::staticMetaObject = { {
    QMetaObject::SuperData::link<StartPage::staticMetaObject>(),
    qt_meta_stringdata_HoursMonitorPage.data,
    qt_meta_data_HoursMonitorPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *HoursMonitorPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *HoursMonitorPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_HoursMonitorPage.stringdata0))
        return static_cast<void*>(this);
    return StartPage::qt_metacast(_clname);
}

int HoursMonitorPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = StartPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_HoursMinimumPage_t {
    QByteArrayData data[1];
    char stringdata0[17];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_HoursMinimumPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_HoursMinimumPage_t qt_meta_stringdata_HoursMinimumPage = {
    {
QT_MOC_LITERAL(0, 0, 16) // "HoursMinimumPage"

    },
    "HoursMinimumPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_HoursMinimumPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void HoursMinimumPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject HoursMinimumPage::staticMetaObject = { {
    QMetaObject::SuperData::link<StartPage::staticMetaObject>(),
    qt_meta_stringdata_HoursMinimumPage.data,
    qt_meta_data_HoursMinimumPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *HoursMinimumPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *HoursMinimumPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_HoursMinimumPage.stringdata0))
        return static_cast<void*>(this);
    return StartPage::qt_metacast(_clname);
}

int HoursMinimumPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = StartPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_PrimaryDevicePage_t {
    QByteArrayData data[1];
    char stringdata0[18];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PrimaryDevicePage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PrimaryDevicePage_t qt_meta_stringdata_PrimaryDevicePage = {
    {
QT_MOC_LITERAL(0, 0, 17) // "PrimaryDevicePage"

    },
    "PrimaryDevicePage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PrimaryDevicePage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void PrimaryDevicePage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject PrimaryDevicePage::staticMetaObject = { {
    QMetaObject::SuperData::link<StartPage::staticMetaObject>(),
    qt_meta_stringdata_PrimaryDevicePage.data,
    qt_meta_data_PrimaryDevicePage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PrimaryDevicePage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PrimaryDevicePage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PrimaryDevicePage.stringdata0))
        return static_cast<void*>(this);
    return StartPage::qt_metacast(_clname);
}

int PrimaryDevicePage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = StartPage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_InternetPage_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_InternetPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_InternetPage_t qt_meta_stringdata_InternetPage = {
    {
QT_MOC_LITERAL(0, 0, 12) // "InternetPage"

    },
    "InternetPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_InternetPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void InternetPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject InternetPage::staticMetaObject = { {
    QMetaObject::SuperData::link<StartPage::staticMetaObject>(),
    qt_meta_stringdata_InternetPage.data,
    qt_meta_data_InternetPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *InternetPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InternetPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_InternetPage.stringdata0))
        return static_cast<void*>(this);
    return StartPage::qt_metacast(_clname);
}

int InternetPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = StartPage::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
