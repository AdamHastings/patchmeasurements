/****************************************************************************
** Meta object code from reading C++ file 'SingleChoicePage.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../SingleChoicePage.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'SingleChoicePage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SingleChoicePage_t {
    QByteArrayData data[1];
    char stringdata0[17];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SingleChoicePage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SingleChoicePage_t qt_meta_stringdata_SingleChoicePage = {
    {
QT_MOC_LITERAL(0, 0, 16) // "SingleChoicePage"

    },
    "SingleChoicePage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SingleChoicePage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void SingleChoicePage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject SingleChoicePage::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_SingleChoicePage.data,
    qt_meta_data_SingleChoicePage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SingleChoicePage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SingleChoicePage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SingleChoicePage.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int SingleChoicePage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_PreWTAPage_t {
    QByteArrayData data[1];
    char stringdata0[11];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PreWTAPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PreWTAPage_t qt_meta_stringdata_PreWTAPage = {
    {
QT_MOC_LITERAL(0, 0, 10) // "PreWTAPage"

    },
    "PreWTAPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PreWTAPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void PreWTAPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject PreWTAPage::staticMetaObject = { {
    QMetaObject::SuperData::link<SingleChoicePage::staticMetaObject>(),
    qt_meta_stringdata_PreWTAPage.data,
    qt_meta_data_PreWTAPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PreWTAPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PreWTAPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PreWTAPage.stringdata0))
        return static_cast<void*>(this);
    return SingleChoicePage::qt_metacast(_clname);
}

int PreWTAPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SingleChoicePage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_PostTasksPage_t {
    QByteArrayData data[1];
    char stringdata0[14];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PostTasksPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PostTasksPage_t qt_meta_stringdata_PostTasksPage = {
    {
QT_MOC_LITERAL(0, 0, 13) // "PostTasksPage"

    },
    "PostTasksPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PostTasksPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void PostTasksPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject PostTasksPage::staticMetaObject = { {
    QMetaObject::SuperData::link<SingleChoicePage::staticMetaObject>(),
    qt_meta_stringdata_PostTasksPage.data,
    qt_meta_data_PostTasksPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PostTasksPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PostTasksPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PostTasksPage.stringdata0))
        return static_cast<void*>(this);
    return SingleChoicePage::qt_metacast(_clname);
}

int PostTasksPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SingleChoicePage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_FinalPage_t {
    QByteArrayData data[1];
    char stringdata0[10];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FinalPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FinalPage_t qt_meta_stringdata_FinalPage = {
    {
QT_MOC_LITERAL(0, 0, 9) // "FinalPage"

    },
    "FinalPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FinalPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void FinalPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject FinalPage::staticMetaObject = { {
    QMetaObject::SuperData::link<SingleChoicePage::staticMetaObject>(),
    qt_meta_stringdata_FinalPage.data,
    qt_meta_data_FinalPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *FinalPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FinalPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_FinalPage.stringdata0))
        return static_cast<void*>(this);
    return SingleChoicePage::qt_metacast(_clname);
}

int FinalPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SingleChoicePage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_NoAdminPage_t {
    QByteArrayData data[1];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NoAdminPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NoAdminPage_t qt_meta_stringdata_NoAdminPage = {
    {
QT_MOC_LITERAL(0, 0, 11) // "NoAdminPage"

    },
    "NoAdminPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NoAdminPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void NoAdminPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject NoAdminPage::staticMetaObject = { {
    QMetaObject::SuperData::link<SingleChoicePage::staticMetaObject>(),
    qt_meta_stringdata_NoAdminPage.data,
    qt_meta_data_NoAdminPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *NoAdminPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NoAdminPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_NoAdminPage.stringdata0))
        return static_cast<void*>(this);
    return SingleChoicePage::qt_metacast(_clname);
}

int NoAdminPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SingleChoicePage::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_Failed2UploadPage_t {
    QByteArrayData data[1];
    char stringdata0[18];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Failed2UploadPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Failed2UploadPage_t qt_meta_stringdata_Failed2UploadPage = {
    {
QT_MOC_LITERAL(0, 0, 17) // "Failed2UploadPage"

    },
    "Failed2UploadPage"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Failed2UploadPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void Failed2UploadPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject Failed2UploadPage::staticMetaObject = { {
    QMetaObject::SuperData::link<SingleChoicePage::staticMetaObject>(),
    qt_meta_stringdata_Failed2UploadPage.data,
    qt_meta_data_Failed2UploadPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Failed2UploadPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Failed2UploadPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Failed2UploadPage.stringdata0))
        return static_cast<void*>(this);
    return SingleChoicePage::qt_metacast(_clname);
}

int Failed2UploadPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SingleChoicePage::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
